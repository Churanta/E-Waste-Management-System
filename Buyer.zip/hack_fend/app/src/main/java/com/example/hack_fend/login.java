package com.example.hack_fend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {


    TextView signin,textView2;
    private Button login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signin = (TextView) findViewById(R.id.signin);
//        Log.d("myTag", signin.toString());
//        signin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(login.this,Register.class);
//                startActivity(intent);
//
//
//                Toast.makeText(login.this,"Register yourself",Toast.LENGTH_SHORT).show();
//            }
//        });

        login= (Button) findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(login.this,MainPage.class);
                startActivity(intent);


                Toast.makeText(login.this,"Hi there \n Welcome",Toast.LENGTH_SHORT).show();
            }
        });
        textView2= (TextView) findViewById(R.id.textView2);
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(login.this,Forgot_password.class);
                startActivity(intent);


                Toast.makeText(login.this,"Forgot Password",Toast.LENGTH_SHORT).show();
            }
        });

    }
}