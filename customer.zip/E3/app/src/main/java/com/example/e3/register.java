package com.example.e3;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;

import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity implements View.OnClickListener{

    private TextView banner,directlink;
    private EditText rname,rpass,remail,rmob;
    private Button register;
    private ProgressBar progressBar;


    private FirebaseAuth mAuth;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        //Direct to main page

        directlink=(TextView)findViewById(R.id.directlink);
        directlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(register.this,MainPage.class);
                startActivity(intent);

                Toast.makeText(register.this,"You have been successfully registered",Toast.LENGTH_SHORT).show();
            }
        });

        mAuth=FirebaseAuth.getInstance();

        //banner is used to send back to login page
        banner=(TextView) findViewById(R.id.banner);
        banner.setOnClickListener(this);

        register=(Button) findViewById(R.id.register);
        register.setOnClickListener(this);

        rname=(EditText) findViewById(R.id.rname);
        rpass=(EditText) findViewById(R.id.rpass);
        remail=(EditText) findViewById(R.id.remail);
        rmob=(EditText) findViewById(R.id.rmob);

        progressBar=(ProgressBar) findViewById(R.id.progressBar);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.banner:
                startActivity(new Intent(this,loginSc.class));
                break;

            case R.id.register:
                register ();
                break;


        }

    }

    private void register2(){

    }


    // register is used to add the details
    private void register() {
        String name=rname.getText().toString().trim();
        String mobile=rmob.getText().toString().trim();
        String email=remail.getText().toString().trim();
        String password=rpass.getText().toString().trim();

        //Validating
        if(name.isEmpty()){
            rname.setError("Full Name is Required");
            rname.requestFocus();
            return;
        }

        if(mobile.isEmpty()){
            rmob.setError("Mobile Number is Required");
            rmob.requestFocus();
            return;
        }

        if(email.isEmpty()){
            remail.setError("Email-ID is Required");
            remail.requestFocus();
            return;
        }

        //to check email is correct or not
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            remail.setError("Please Provide a Valid Email ID");
            remail.requestFocus();
            return;
        }

        if(password.isEmpty()){
            rpass.setError("Mobile Number is Required");
            rpass.requestFocus();
            return;
        }
        if(password.length()<6){
           rpass.setError("Minimum Password Length should be of 6 Characters...");
           rpass.requestFocus();
            return;
        }

//        progressBar.setVisibility(View.VISIBLE);
//        mAuth.createUserWithEmailAndPassword(email,password);
//                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if(task.isSuccessful()){
//                            User user= new User(name,mobile,email);
//
//
//                            //Registering User
//                            FirebaseDatabase.getInstance().getReference("Users")
//                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
//                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
//                                @Override
//                                public void onComplete(@NonNull Task<Void> task) {
//                                    if (task.isSuccessful()) {
//                                        Toast.makeText(register.this, "User has been registered successfully", Toast.LENGTH_LONG).show();
//
//                                        //redirect to login layout!
//
//                                    }else {
//                                        Toast.makeText(register.this, "Failed to register ! Try again", Toast.LENGTH_LONG).show();
//                                        progressBar.setVisibility(View.GONE);
//                                    }
//                                }
//                                });
//
//
//                            }else {
//                            Toast.makeText(register.this, "Failed to register ! Try again", Toast.LENGTH_LONG).show();
//                            progressBar.setVisibility(View.GONE);
//                        }
//                        }
//                });
                }
    }