package com.example.e3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class loginSc extends AppCompatActivity {
    TextView signin;
    private Button llogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sc);

        //code starts for signin text view
        signin = (TextView) findViewById(R.id.SignIn);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginSc.this, register.class);
                startActivity(intent);

                Toast.makeText(loginSc.this, "Register Yourself", Toast.LENGTH_SHORT).show();

                // code stops here for signin tex view
            }


        });
        llogin = (Button) findViewById(R.id.llogin);
        llogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginSc.this, MainPage.class);
                startActivity(intent);

                Toast.makeText(loginSc.this, "Welcome", Toast.LENGTH_SHORT).show();
            }
        });








    }
}