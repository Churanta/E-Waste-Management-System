package com.example.e3;

public class User {
    public String name,mobile,email;

    public User(){


    }

    public User(String name,String mobile,String email){
        this.name=name;
        this.mobile=mobile;
        this.email=email;
    }
}
